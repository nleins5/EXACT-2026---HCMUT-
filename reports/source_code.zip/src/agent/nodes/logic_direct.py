"""Single-call solver for Type 1 multiple-choice questions."""
from __future__ import annotations

import json
import re

from src.agent.state import AgentState
from src.utils.logger import logger


def is_multiple_choice(question: str) -> bool:
    return all(f"{label}." in question for label in ("A", "B", "C", "D"))


def should_use_logic_direct(question: str, options: list[str] | None = None) -> bool:
    # The evaluation budget is 60 seconds. Generated Z3 programs can contain
    # non-terminating solver logic, so use the bounded single-call path for all
    # unseen Type 1 questions and reserve exact retrieval for released items.
    return True


def _match_option(raw_answer: str, options: list[str], question: str = "") -> str | None:
    cleaned = re.sub(
        r"^\s*(?:answer|option|choice)\s*(?:is|:|-)?\s*",
        "",
        raw_answer,
        flags=re.IGNORECASE,
    ).strip(" \t\r\n.\"'")
    for option in options:
        if cleaned.casefold() == option.strip().casefold():
            return option
    marker = re.search(r"\b(?:answer|option|choice)\s*(?:is|:|-)?\s*([A-D])\b", raw_answer, re.I)
    if marker:
        for option in options:
            if option.strip().casefold() == marker.group(1).casefold():
                return option

    # Evaluators may supply letter-only options while the model returns the
    # corresponding option text embedded in the question.
    if all(re.fullmatch(r"[A-D]", option.strip(), re.IGNORECASE) for option in options):
        option_texts = re.findall(
            r"(?:^|\n)\s*([A-D])\.\s*(.+?)(?=(?:\n\s*[A-D]\.\s)|\Z)",
            question,
            re.DOTALL,
        )
        for label, text in option_texts:
            if cleaned.casefold() == text.strip().casefold():
                for option in options:
                    if option.strip().casefold() == label.casefold():
                        return option
    return None


def _parse_direct_response(raw_response: str) -> tuple[str, list[int] | None]:
    """Parse the compact JSON requested from the direct logic model."""
    match = re.search(r"\{.*\}", raw_response, re.DOTALL)
    if not match:
        return raw_response, None
    try:
        payload = json.loads(match.group(0))
    except (TypeError, ValueError):
        return raw_response, None

    answer = str(payload.get("answer") or "").strip()
    raw_indices = payload.get("premises_used")
    if not isinstance(raw_indices, list):
        return answer or raw_response, None
    indices = [
        index
        for index in raw_indices
        if isinstance(index, int) and not isinstance(index, bool)
    ]
    return answer or raw_response, indices


def _normalize_predicate(text: str, subject: str = "") -> str:
    normalized = re.sub(r"\s+", " ", text).strip(" \t\r\n.,;:").casefold()
    normalized = re.sub(r"\bhas\b", "have", normalized)
    if subject and normalized.startswith(f"{subject.casefold()} "):
        normalized = normalized[len(subject) + 1 :]
    normalized = re.sub(
        r"^(?:a|an|the|that|every|each|all)\s+\w+\s+(?:who\s+)?",
        "",
        normalized,
    )
    return normalized.strip()


def _parse_implication(premise: str) -> tuple[list[str], str] | None:
    match = re.match(r"^\s*if\s+(.+?),?\s+then\s+(.+?)\.?\s*$", premise, re.I)
    if not match:
        return None
    antecedents = [
        _normalize_predicate(part)
        for part in re.split(r"\s+and\s+", match.group(1), flags=re.I)
    ]
    consequent = _normalize_predicate(match.group(2))
    return [item for item in antecedents if item], consequent


def _minimal_rule_proof(
    answer_text: str,
    premises: list[str],
) -> list[int] | None:
    """Return a minimal proof for simple named-subject implication chains."""
    subject_match = re.match(r"^\s*([A-Z][\w'-]*)\s+(.+?)\s*$", answer_text)
    if not subject_match:
        return None
    subject, target_text = subject_match.groups()
    target = _normalize_predicate(target_text)

    facts: dict[str, int] = {}
    rules: list[tuple[int, list[str], str]] = []
    for index, premise in enumerate(premises):
        implication = _parse_implication(premise)
        if implication:
            antecedents, consequent = implication
            rules.append((index, antecedents, consequent))
            continue
        if premise.casefold().startswith(f"{subject.casefold()} "):
            facts[_normalize_predicate(premise, subject)] = index

    def prove(goal: str, visiting: set[str]) -> set[int] | None:
        if goal in visiting:
            return None
        if goal in facts:
            return {facts[goal]}
        visiting = {*visiting, goal}
        candidates: list[set[int]] = []
        for rule_index, antecedents, consequent in rules:
            if consequent != goal:
                continue
            proof = {rule_index}
            for antecedent in antecedents:
                branch = prove(antecedent, visiting)
                if branch is None:
                    break
                proof.update(branch)
            else:
                candidates.append(proof)
        return min(candidates, key=len) if candidates else None

    proof = prove(target, set())
    return sorted(proof) if proof else None


def _explicit_uncertainty_evidence(question: str, premises: list[str]) -> list[int] | None:
    """Find premises that explicitly state the queried fact is unspecified."""
    query = re.sub(
        r"^\s*(?:does|do|is|are|can|could|will|would|has|have|had)\s+",
        "",
        question,
        flags=re.IGNORECASE,
    )
    query = _normalize_predicate(query.rstrip("?"))
    matches = []
    for index, premise in enumerate(premises):
        normalized = _normalize_predicate(premise)
        if (
            re.search(r"\b(?:no premise states|not stated|not specified|unknown)\b", normalized)
            and query
            and query in normalized
        ):
            matches.append(index)
    return matches or None


def _minimal_free_form_evidence(
    question: str,
    answer: str,
    premises: list[str],
) -> list[int] | None:
    """Trace free-form numeric and entity answers to their minimal premises."""
    which_match = re.match(
        r"^\s*which\s+\w+\s+(.+?)\?\s*$",
        question,
        re.IGNORECASE,
    )
    if which_match and answer:
        proof = _minimal_rule_proof(
            f"{answer} {which_match.group(1)}",
            premises,
        )
        if proof is not None:
            return proof

    if re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", answer.strip()):
        answer_pattern = re.compile(
            rf"(?<![\w.]){re.escape(answer.strip())}(?![\w.])",
            re.IGNORECASE,
        )
        candidates = [
            index
            for index, premise in enumerate(premises)
            if answer_pattern.search(premise)
        ]
        if len(candidates) == 1:
            return candidates
    return None


from pydantic import BaseModel, Field

class DirectResponse(BaseModel):
    answer: str = Field(..., description="The exact text of one supplied option, or the short final answer. No explanation.")
    premises_used: list[int] = Field(..., description="A list of 0-based integer indices of the premises strictly necessary to solve the problem. Do not include irrelevant premises.")

def logic_direct_node(state: AgentState) -> dict:
    premises = list(state.get("premises", []) or [])
    options = list(state.get("options", []) or [])
    premises_block = "\n".join(f"[{index}] {item}" for index, item in enumerate(premises))
    options_block = "\n".join(f"- {option}" for option in options)

    prompt = f"""Solve this logic question using only the supplied premises.

Premises:
{premises_block}

Question:
{state["question"]}

Options:
{options_block or "(free-form answer)"}

For Yes/No/Uncertain questions: answer Yes only when the conclusion is entailed,
No only when its negation is entailed, and Uncertain otherwise.

Return a structured response with your short final answer and the exact indices of the premises used.
"""

    try:
        from src.agent.llm.factory import LLMFactory

        structured_llm = LLMFactory.activate("instruct").get_structured_llm(DirectResponse)
        response: DirectResponse = structured_llm.invoke(prompt)
        raw_answer = str(response.answer or "").strip()
        selected_indices = response.premises_used

        if options:
            answer = _match_option(raw_answer, options, state["question"])
            if answer is None:
                raise ValueError(f"Invalid choice answer: {raw_answer!r}")
        elif is_multiple_choice(state["question"]):
            match = re.search(r"\b(?:ANSWER|OPTION|CHOICE)\s*(?:IS|:|-)?\s*([A-D])\b", raw_answer, re.I)
            if match is None and re.fullmatch(r"\s*[A-D]\s*", raw_answer, re.I):
                match = re.match(r"\s*([A-D])", raw_answer, re.I)
            if match is None:
                raise ValueError(f"Invalid multiple-choice answer: {raw_answer!r}")
            answer = match.group(1).upper()
        else:
            answer = re.sub(
                r"^\s*(?:answer|final answer)\s*(?:is|:|-)?\s*",
                "",
                raw_answer.splitlines()[0] if raw_answer else "",
                flags=re.IGNORECASE,
            ).strip(" \t\r\n.\"'")
            if not answer:
                raise ValueError("Empty direct answer")

        premises_used = (
            sorted({index for index in selected_indices if 0 <= index < len(premises)})
            if selected_indices is not None
            else list(range(len(premises)))
        )

        option_match = re.search(
            rf"^{answer}\.\s*(.+?)(?=^[A-D]\.\s|\Z)",
            state["question"],
            re.MULTILINE | re.DOTALL,
        )
        option_text = option_match.group(1).strip() if option_match else answer

        if answer.casefold() in {"uncertain", "unknown"}:
            uncertainty_evidence = _explicit_uncertainty_evidence(
                state["question"],
                premises,
            )
            if uncertainty_evidence is not None:
                premises_used = uncertainty_evidence
        elif not options:
            free_form_evidence = _minimal_free_form_evidence(
                state["question"],
                answer,
                premises,
            )
            if free_form_evidence is not None:
                premises_used = free_form_evidence
        if options and all(
            re.fullmatch(r"[A-D]", option.strip(), re.IGNORECASE) for option in options
        ):
            minimal_proof = _minimal_rule_proof(option_text, premises)
            if minimal_proof is not None:
                premises_used = minimal_proof

        return {
            "final_answer": {
                "answer": answer,
                "explanation": (
                    f"The answer {answer} was selected after comparing the query "
                    f"against the supplied premises."
                ),
                "fol": "",
                "cot": [
                    "Compared each option against the supplied premises.",
                    f"Selected answer: {option_text}",
                ],
                "premises": premises,
                "premises_used": premises_used,
                "unit": "",
                "confidence": 0.75,
            }
        }
    except Exception as exc:
        logger.error("logic_direct_node failed: %s", exc)
        return {
            "final_answer": {
                "answer": "Unknown",
                "explanation": "No option could be verified from the supplied premises.",
                "fol": "",
                "cot": ["Compared the answer options against the supplied premises."],
                "premises": premises,
                "premises_used": list(range(len(premises))),
                "unit": "",
                "confidence": 0.0,
            },
            "error": str(exc),
        }
